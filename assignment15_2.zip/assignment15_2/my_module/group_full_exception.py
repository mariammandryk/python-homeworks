class GroupFullException(Exception):
    pass